﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Program
    {
        static readonly string baseUrl = "http://localhost:56754";
        static HttpClient client = new HttpClient();

        static void Main(string[] args)
        {
            RunAsync().Wait();
        }

        static async Task RunAsync()
        {

            client.BaseAddress = new Uri(baseUrl);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var id  = 4;
            var ssn = 5;

            var vehicleTask = VehicleAsync(id);
            var taxesAndFeesTask = TaxesAndFeesAsync(id);
            var discountTask = DiscountAsync(id);
            var creditTask = CreditAsync(ssn);

            await Task.WhenAll(vehicleTask, taxesAndFeesTask, discountTask, creditTask);

            var vehicle = await vehicleTask;
            var taxesAndFees = await taxesAndFeesTask;
            var discount = await discountTask;
            var credit = await creditTask;

            var SalePriceRequestModel = new SalePriceRequestModel { Taxes= taxesAndFees.Taxes, Fees = taxesAndFees.Faxes, MSRP = vehicle.MSRP, Id = id, Credit= credit.Credit, Discounts = discount.Discount};
            var salePriceTask = SalesPriceAsync(SalePriceRequestModel);

        }

        static async Task<VehicleResult> VehicleAsync(int id)
        {
            var response = await client.GetAsync($"/vehicle/{id}");
            return await DeserializeVehicleResponseContent(response);
        }

        static async Task<TaxesAndFeesResult> TaxesAndFeesAsync(int id)
        {
            var response = await client.GetAsync($"/taxfee/{id}");
            return await DeserializeTaxesAndFeesResponseContent(response);
        }

        static async Task<DiscountResult> DiscountAsync(int id)
        {
            var response = await client.GetAsync($"/discount/{id}");
            return await DeserializeDiscountResponseContent(response);
        }

        static async Task<CreditResult> CreditAsync(int ssn)
        {
            var response = await client.GetAsync($"/credit/{ssn}");
            return await DeserializeCreditResponseContent(response);
        }

        static async Task<SalePriceResult> SalesPriceAsync(SalePriceRequestModel input)
        {
            HttpResponseMessage response = await client.PostAsJsonAsync("/carprice/saleprice", input);
            return await DeserializeSalesPriceResponseContent(response);
        }


        static async Task<VehicleResult> DeserializeVehicleResponseContent(HttpResponseMessage response)
        {
            var vehicleResult = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<VehicleResult>(vehicleResult);
        }

        static async Task<TaxesAndFeesResult> DeserializeTaxesAndFeesResponseContent(HttpResponseMessage response)
        {
            var transactionResult = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<TaxesAndFeesResult>(transactionResult);
        }

        static async Task<CreditResult> DeserializeCreditResponseContent(HttpResponseMessage response)
        {
            var creditResult = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<CreditResult>(creditResult);
        }

        static async Task<DiscountResult> DeserializeDiscountResponseContent(HttpResponseMessage response)
        {
            var discountResult = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<DiscountResult>(discountResult);
        }

        static async Task<SalePriceResult> DeserializeSalesPriceResponseContent(HttpResponseMessage response)
        {
            var salesPriceResult = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<SalePriceResult>(salesPriceResult);
        }




    }
}
