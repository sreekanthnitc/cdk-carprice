﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp
{
    public class CreditResult
    {
        public int SSN { get; set; }

        public double Credit { get; set; }

        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
    }

    public class DiscountResult
    {
        public int Id { get; set; }

        public double Discount { get; set; }

        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
    }

    public class SalePriceResult
    {
        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
    }

    public class TaxesAndFeesResult 
    {
        public double Taxes { get; set; }
        public double Faxes { get; set; }

        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
    }

    public class VehicleResult
    {
        public int Id { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int Style { get; set; }
        public int MSRP { get; set; }
    }

    public class SalePriceRequestModel
    {
        public int Id { get; set; }
        public double MSRP { get; set; }
        public double Taxes { get; set; }
        public double Fees { get; set; }
        public double Discounts { get; set; }
        public double Credit { get; set; }
    }
}
