﻿using CarPrice.Exceptions;
using CarPrice.Model.Credit;
using System.Threading.Tasks;

namespace CarPrice.Validation
{
    public static class CreditValidation
    {
        public static async Task Validate(this CreditModel credit, int ssn)
        {
            if (credit == null)
            {
                throw new InvalidCreditException(ssn);
            }

            await Task.CompletedTask;
        }
    }
}
