﻿using CarPrice.Exceptions;
using CarPrice.Model.Discount;
using System.Threading.Tasks;

namespace CarPrice.Validation
{
    public static class DiscountValidation
    {
        public static async Task Validate(this DiscountModel discount, int id)
        {
            if (discount == null)
            {
                throw new InvalidDiscountException(id);
            }

            await Task.CompletedTask;
        }
    }
}
