﻿using CarPrice.Exceptions;
using CarPrice.Model.TaxesAndFees;
using System.Threading.Tasks;

namespace CarPrice.Validation
{
    public static class TaxesAndFeesValidation
    {
       
            public static async Task Validate(this TaxesAndFeesModel taxesAndFees, TaxesAndFeesRequestModel request)
            {
                if (taxesAndFees == null)
                {
                    throw new InvalidTaxesAndFeesException(request);
                }

                await Task.CompletedTask;
            }
        }
 
}
