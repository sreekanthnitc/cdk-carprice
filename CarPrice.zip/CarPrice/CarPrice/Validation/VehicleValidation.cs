﻿using CarPrice.Exceptions;
using CarPrice.Model;
using CarPrice.Model.TaxesAndFees;
using System.Threading.Tasks;

namespace CarPrice.Validation
{
    public static class VehicleValidation
    {
        public static async Task Validate(this VehicleModel vehicle, int id )
        {
            if (vehicle == null)
            {
                throw new InvalidVehicleException(id);
            }

            await Task.CompletedTask;
        }
    }
}
 
