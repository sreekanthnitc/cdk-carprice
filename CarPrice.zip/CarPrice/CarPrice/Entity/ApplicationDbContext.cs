﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CarPrice.Entity
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Model creation goes here

            base.OnModelCreating(modelBuilder);
        }
    }
}
