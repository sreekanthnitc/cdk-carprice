﻿namespace CarPrice.Entity.Credit
{
    public class CreditEntity
    {
        public int SSN { get; set; }

        public double Credit { get; set; }
    }
}
