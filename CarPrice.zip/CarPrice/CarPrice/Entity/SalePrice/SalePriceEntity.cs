﻿namespace CarPrice.Entity.SalePrice
{
    public class SalePriceEntity
    {
        public int Id { get; set; }

        public double SalePrice { get; set; }
    }
}
