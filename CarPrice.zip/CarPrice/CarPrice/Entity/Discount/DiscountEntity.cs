﻿
namespace CarPrice.Entity.Discount
{
    public class DiscountEntity
    {
        public int Id { get; set; }

        public double Discount { get; set; }
    }
}
