﻿using AutoMapper;
using CarPrice.Entity.SalePrice;
using CarPrice.Model.SalePrice;
using CarPrice.Repositories.SalePrice;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace CarPrice.Services.SalePrice
{
    public class SalePriceCore : ISalePriceCore
    {
        private readonly ISalePriceRepository _salepriceRepository;

        private readonly IMapper _mapper;
        private readonly ILogger _logger;

        public SalePriceCore(ISalePriceRepository salePriceRepository, IMapper mapper, ILogger<SalePriceCore> logger)
        {
            _salepriceRepository = salePriceRepository ?? throw new ArgumentNullException(nameof(salePriceRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<SalePriceResult> SaveSalePriceDetails(SalePriceRequestModel input)
        {
            var savePriceModel = await SaveCreditInformation(input);
            var savePriceResult = _mapper.Map<SalePriceResult>(savePriceModel);

            _logger.LogInformation("1004", "SavePrice :{0}", JsonConvert.SerializeObject(savePriceResult));
            return savePriceResult;
        }

        #region private helpers

        private async Task<SalePriceResult> SaveCreditInformation(SalePriceRequestModel input)
        {
            var salePrice = input.MSRP - input.Discounts + input.Taxes + input.Fees;
            var salePriceEntity = new SalePriceEntity { Id = input.Id, SalePrice = salePrice };
            await _salepriceRepository.Save(salePriceEntity);
            var result = _mapper.Map<SalePriceResult>(salePriceEntity);
            return result;
        }

        #endregion
    }
}
