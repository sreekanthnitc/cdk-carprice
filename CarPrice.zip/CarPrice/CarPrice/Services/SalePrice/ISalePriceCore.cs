﻿using CarPrice.Model.SalePrice;
using System.Threading.Tasks;

namespace CarPrice.Services.SalePrice
{
    public interface ISalePriceCore
    {
        Task<SalePriceResult> SaveSalePriceDetails(SalePriceRequestModel input);
    }
}
