﻿using AutoMapper;
using CarPrice.Model;
using CarPrice.Repositories.Vehicle;
using CarPrice.Validation;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace CarPrice.Services.Vehicle
{
    public class VehicleCore : IVehicleCore
    {
        private readonly IVehicleRepository _vehicleRepository;

        private readonly IMapper _mapper;
        private readonly ILogger _logger;

        public VehicleCore(IVehicleRepository vehicleRepository, IMapper mapper, ILogger<VehicleCore> logger)
        {
            _vehicleRepository = vehicleRepository ?? throw new ArgumentNullException(nameof(vehicleRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<VehicleResult> GeVehicleDetails(int id)
        {
            var vehicleModel = await GetVehicleInformation(id);
            await vehicleModel.Validate(id);
            var vehicleResult = _mapper.Map<VehicleResult>(vehicleModel);

            _logger.LogInformation("1001", "Vehicle result:{0}", JsonConvert.SerializeObject(vehicleResult));
            return vehicleResult;
        }

        #region private helpers

        private async Task<VehicleModel> GetVehicleInformation(int id)
        {
            var vehicleEntity = await _vehicleRepository.Read(id);
            return _mapper.Map<VehicleModel>(vehicleEntity);
        }

        #endregion
    }
}
