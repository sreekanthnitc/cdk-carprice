﻿using CarPrice.Model;
using System.Threading.Tasks;

namespace CarPrice.Services.Vehicle
{
    public interface IVehicleCore
    {
        Task<VehicleResult> GeVehicleDetails(int id);
    }
}
