﻿using CarPrice.Model.Discount;
using System.Threading.Tasks;

namespace CarPrice.Services.Discount
{
    public interface IDiscountCore
    {
        Task<DiscountResult> GetDiscountDetails(int id);
    }
}
