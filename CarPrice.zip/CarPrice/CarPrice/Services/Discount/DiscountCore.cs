﻿using AutoMapper;
using CarPrice.Model.Discount;
using CarPrice.Repositories.Discount;
using CarPrice.Validation;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace CarPrice.Services.Discount
{
    public class DiscountCore : IDiscountCore
    {
        private readonly IDiscountRepository _discountRepository;

        private readonly IMapper _mapper;
        private readonly ILogger _logger;

        public DiscountCore(IDiscountRepository discountRepository, IMapper mapper, ILogger<DiscountCore> logger)
        {
            _discountRepository = discountRepository ?? throw new ArgumentNullException(nameof(discountRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<DiscountResult> GetDiscountDetails(int id)
        {
            var discountModel = await GetDiscountInformation(id);
            await discountModel.Validate(id);
            var discountResult = _mapper.Map<DiscountResult>(discountModel);

            _logger.LogInformation("1003", "discount Discount:{0}", JsonConvert.SerializeObject(discountResult));
            return discountResult;
        }

        #region private helpers

        private async Task<DiscountModel> GetDiscountInformation(int id)
        {
            var discountEntity = await _discountRepository.Read(id);
            return _mapper.Map<DiscountModel>(discountEntity);
        }

        #endregion
    }
}
