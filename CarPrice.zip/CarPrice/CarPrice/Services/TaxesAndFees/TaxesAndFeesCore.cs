﻿using AutoMapper;
using CarPrice.Model;
using CarPrice.Model.TaxesAndFees;
using CarPrice.Repositories.TaxesAndFees;
using CarPrice.Repositories.Vehicle;
using CarPrice.Validation;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace CarPrice.Services.TaxesAndFees
{
    public class TaxesAndFeesCore : ITaxesAndFeesCore
    {
        private readonly ITaxesAndFeesRepository _taxesAndFeesRepository;
        private readonly IVehicleRepository _vehicleRepository;

        private readonly IMapper _mapper;
        private readonly ILogger _logger;

        public TaxesAndFeesCore(ITaxesAndFeesRepository taxesAndFeesRepository, IMapper mapper, ILogger<TaxesAndFeesCore> logger, IVehicleRepository vehicleRepository)
        {
            _taxesAndFeesRepository = taxesAndFeesRepository ?? throw new ArgumentNullException(nameof(taxesAndFeesRepository));
            _vehicleRepository = vehicleRepository  ?? throw new ArgumentNullException(nameof(taxesAndFeesRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<TaxesAndFeesModel> GeTaxAndFeesDetails(int id)
        {
            var vehicleEntity = await _vehicleRepository.Read(id);
            var vehicleModel = _mapper.Map<VehicleModel>(vehicleEntity);

            var inputModel = new TaxesAndFeesRequestModel { Make = vehicleModel.Make, Model = vehicleModel.Model, Year = vehicleModel.Year };

            var taxesAndFeesModelModel = await GetTaxesAndFeesInformation(inputModel);
            await taxesAndFeesModelModel.Validate(inputModel);
            var taxesAndFeesResult = _mapper.Map<TaxesAndFeesModel>(taxesAndFeesModelModel);

            _logger.LogInformation("1002", "Taxes And Fees result:{0}", JsonConvert.SerializeObject(taxesAndFeesResult));
            return taxesAndFeesResult;
        }

        #region private helpers

        private async Task<TaxesAndFeesModel> GetTaxesAndFeesInformation(TaxesAndFeesRequestModel inputModel)
        {
            var taxesAndFeesModelEntity = await _taxesAndFeesRepository.Read(inputModel);
            return _mapper.Map<TaxesAndFeesModel>(taxesAndFeesModelEntity);
        }

        #endregion
    }
}
