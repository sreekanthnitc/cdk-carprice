﻿using CarPrice.Model.Credit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarPrice.Services.Credit
{
   public interface ICreditCore
    {
        Task<CreditResult> GetCreditDetails(int ssn);
    }
}
