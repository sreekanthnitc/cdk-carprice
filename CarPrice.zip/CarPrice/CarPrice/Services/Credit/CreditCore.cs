﻿using AutoMapper;
using CarPrice.Model.Credit;
using CarPrice.Repositories.TaxesAndFees;
using CarPrice.Validation;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace CarPrice.Services.Credit
{
    public class CreditCore : ICreditCore
    {
        private readonly ICreditRepository _creditRepository;

        private readonly IMapper _mapper;
        private readonly ILogger _logger;

        public CreditCore(ICreditRepository creditRepository, IMapper mapper, ILogger<CreditCore> logger)
        {
            _creditRepository = creditRepository ?? throw new ArgumentNullException(nameof(creditRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<CreditResult> GetCreditDetails(int ssn)
        {
            var CreditModel = await GetCreditInformation(ssn);
            await CreditModel.Validate(ssn);
            var creditResult = _mapper.Map<CreditResult>(CreditModel);

            _logger.LogInformation("1003", "Credit Credit:{0}", JsonConvert.SerializeObject(creditResult));
            return creditResult;
        }

        #region private helpers

        private async Task<CreditModel> GetCreditInformation(int ssn)
        {
            var CreditEntity = await _creditRepository.Read(ssn);
            return _mapper.Map<CreditModel>(CreditEntity);
        }

        #endregion
    }
}
