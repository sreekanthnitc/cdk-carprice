﻿namespace CarPrice.Model.Credit
{
    public class CreditModel
    {
        public int SSN { get; set; }

        public double Credit { get; set; }
    }
}
 
