﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarPrice.Model.Credit
{
    public class CreditResult :CreditModel
    {
        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
    }
}
