﻿namespace CarPrice.Model.TaxesAndFees
{
    public class TaxesAndFeesModel
    {
        public double Taxes { get; set; }
        public double Faxes { get; set; }
    }
}
