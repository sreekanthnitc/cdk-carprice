﻿namespace CarPrice.Model.TaxesAndFees
{
    public class TaxesAndFeesResult : TaxesAndFeesModel
    {
        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
    }
}
