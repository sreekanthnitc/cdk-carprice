﻿namespace CarPrice.Model.SalePrice
{
    public class SalePriceRequestModel
    {
        public int Id { get; set; }
        public  double MSRP { get; set; }
        public double Taxes { get; set; }
        public double Fees { get; set; }
        public double Discounts { get; set; }
        public double Credit { get; set; }
    }
}
