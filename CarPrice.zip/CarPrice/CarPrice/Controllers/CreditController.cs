﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CarPrice.Services.Credit;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CarPrice.Controllers
{
    [Route("api/credit")]
    [ApiController]
    public class CreditController : ControllerBase
    {
        private readonly ICreditCore _creditCore;

        public CreditController(ICreditCore creditCore, IMapper mapper)
        {
            _creditCore = creditCore ?? throw new ArgumentNullException(nameof(creditCore));
        }

        [HttpGet("{ssn}")]
        public async Task<IActionResult> Get(int ssn)
        {
            var creditResult = await _creditCore.GetCreditDetails(ssn);
            return Ok(creditResult);
        }
    }
}