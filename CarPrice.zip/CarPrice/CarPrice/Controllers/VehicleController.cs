﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using CarPrice.Services.Vehicle;
using Microsoft.AspNetCore.Mvc;

namespace CarPrice.Controllers
{
    [Route("api/vehicle")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly IVehicleCore _vehicleCore;

        public VehicleController(IVehicleCore vehicleCore, IMapper mapper)
        {
            _vehicleCore = vehicleCore ?? throw new ArgumentNullException(nameof(vehicleCore));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var vehicleResult = await _vehicleCore.GeVehicleDetails(id);
            return Ok(vehicleResult);
        }

    }
}
