﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CarPrice.Model.SalePrice;
using CarPrice.Services.SalePrice;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CarPrice.Controllers
{
   [ Route("api/carprice")] 
    [ApiController]
    public class SalePriceController : ControllerBase
    {
        private readonly ISalePriceCore _salePriceCore;

        public SalePriceController(ISalePriceCore salePriceCore, IMapper mapper)
        {
            _salePriceCore = salePriceCore ?? throw new ArgumentNullException(nameof(salePriceCore));
        }

        [HttpPost("saleprice")]
        public async Task<IActionResult> Get([FromBody] SalePriceRequestModel salePriceRequestModel)
        {
            var salePriceResult = await _salePriceCore.SaveSalePriceDetails(salePriceRequestModel);
            return Created(string.Empty, salePriceResult);
        }
    }
}