﻿using AutoMapper;
using CarPrice.Services.Discount;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace CarPrice.Controllers
{
    [Route("api/discount")]
    [ApiController]
    public class DiscountController : ControllerBase
    {
        private readonly IDiscountCore _discountCore;

        public DiscountController(IDiscountCore discountCore, IMapper mapper)
        {
            _discountCore = discountCore ?? throw new ArgumentNullException(nameof(discountCore));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var vehicleResult = await _discountCore.GetDiscountDetails(id);
            return Ok(vehicleResult);
        }
    }
}
