﻿using CarPrice.Model.TaxesAndFees;
using CarPrice.Types;
using System;

namespace CarPrice.Exceptions
{
    public abstract class TransactionException : Exception
    {
        public TransactionException(string message)
            : base(message)
        { }

        public abstract int ErrorCode { get; }
    }

    public class InvalidVehicleException : TransactionException
    {
        public InvalidVehicleException(int id)
        : base($"This vehicle {id} does not exist.")
        { }

        public override int ErrorCode =>
            TransactionErrorCode.VehicleDoesNotExistError;
    }

    public class InvalidTaxesAndFeesException : TransactionException
    {
        public InvalidTaxesAndFeesException(TaxesAndFeesRequestModel request)
        : base($"This Model {request.Model}, Make {request.Model}, Year {request.Year} does not have Taxes and Fees.")
        { }

        public override int ErrorCode =>
            TransactionErrorCode.TaxesAndFees;
    }

    public class InvalidCreditException : TransactionException
    {
        public InvalidCreditException(int ssn)
        : base($"This SSN {ssn} does not exist.")
        { }

        public override int ErrorCode =>
            TransactionErrorCode.InvalidSSN;
    }

    public class InvalidDiscountException : TransactionException
    {
        public InvalidDiscountException(int id)
        : base($"This Vehicle {id} does not exist.")
        { }

        public override int ErrorCode =>
            TransactionErrorCode.VehicleDoesNotExistError;
    }
}

