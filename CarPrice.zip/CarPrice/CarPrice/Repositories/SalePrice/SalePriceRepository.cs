﻿
using CarPrice.Entity;
using CarPrice.Entity.SalePrice;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CarPrice.Repositories.SalePrice
{
    public class SalePriceRepository : ISalePriceRepository
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly DbSet<SalePriceEntity> _salePriceEntity;

        public SalePriceRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
            _salePriceEntity = _dbContext.Set<SalePriceEntity>();
        }

        public async Task Save(SalePriceEntity input)
        {
            _salePriceEntity.Add(input);

            try
            {
               await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                throw ex;
            }



        }
    }
}
