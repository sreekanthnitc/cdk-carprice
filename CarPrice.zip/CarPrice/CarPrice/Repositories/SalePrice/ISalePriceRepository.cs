﻿using CarPrice.Entity.SalePrice;
using System.Threading.Tasks;

namespace CarPrice.Repositories.SalePrice
{
    public interface ISalePriceRepository
    {
        Task Save(SalePriceEntity input);
    }
}
