﻿using CarPrice.Entity;
using CarPrice.Entity.Credit;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CarPrice.Repositories.TaxesAndFees
{
    public class CreditRepository : ICreditRepository
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly DbSet<CreditEntity> _creditEntity;

        public CreditRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
            _creditEntity = _dbContext.Set<CreditEntity>();
        }

        public async Task<CreditEntity> Read(int ssn)
        {
            return await _creditEntity.AsNoTracking()
                .FirstOrDefaultAsync(e => e.SSN == ssn);
        }
    }
}
