﻿using CarPrice.Entity.Credit;
using CarPrice.Entity.TaxAndFees;
using CarPrice.Model.TaxesAndFees;
using System.Threading.Tasks;

namespace CarPrice.Repositories.TaxesAndFees
{
    public interface ICreditRepository
    {
        Task<CreditEntity> Read(int ssn );
    }
}
