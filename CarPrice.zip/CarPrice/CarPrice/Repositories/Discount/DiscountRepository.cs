﻿using CarPrice.Entity;
using CarPrice.Entity.Discount;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CarPrice.Repositories.Discount
{
    public class DiscountRepository : IDiscountRepository
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly DbSet<DiscountEntity> _discountEntity;

        public DiscountRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
            _discountEntity = _dbContext.Set<DiscountEntity>();
        }

        public async Task<DiscountEntity> Read(int id)
        {
            return await _discountEntity.AsNoTracking()
                .FirstOrDefaultAsync(e => e.Id == id);
        }
    }
}
