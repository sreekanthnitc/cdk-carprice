﻿using CarPrice.Entity.Vehicle;
using System.Threading.Tasks;

namespace CarPrice.Repositories.Vehicle
{
    public interface IVehicleRepository
    {
        Task<VehicleEntity> Read(int id);
    }
}
